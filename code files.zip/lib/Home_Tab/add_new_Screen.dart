import 'package:flutter/material.dart';

class AddNewScreen extends StatelessWidget {
  const AddNewScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Container(
      child: Text('AddNew'),
    ));
  }
}
